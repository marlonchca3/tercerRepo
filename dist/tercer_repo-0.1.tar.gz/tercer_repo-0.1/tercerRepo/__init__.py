def saludar(nombre):
    return f"Hola, {nombre}. Este es mi primer paquete pip."