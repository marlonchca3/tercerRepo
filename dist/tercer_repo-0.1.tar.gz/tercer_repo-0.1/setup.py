from setuptools import setup, find_packages

setup(
    name='tercer_repo',
    version='0.1',
    packages=find_packages(),
    author='marlon',
    author_email='marlonchca3@gmail.com',
    url='https://github.com/marlonchca3/tercerRepo',
)